#!/usr/bin/env python3
"""Top-level entry point shim: `python3 voiceproof.py ...`"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from voiceproof.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
